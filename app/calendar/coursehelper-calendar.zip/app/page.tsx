"use client"
import { CalendarScheduler } from "@/components/calendar-scheduler"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#ffffff]">
      <CalendarScheduler />
    </div>
  )
}
